Description:
    deploying a high availability webapp

LoadBalancer DNS NAME:
    Udagr-WebAp-9M3TXFYO2LR2-1009840014.us-east-1.elb.amazonaws.com

Created by :
    Hoda Mohamed